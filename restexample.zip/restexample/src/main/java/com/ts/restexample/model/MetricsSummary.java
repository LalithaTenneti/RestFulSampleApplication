package com.ts.restexample.model;

public class MetricsSummary {
	
	private String mSys;
	private String mName;
	private int   mFDate;
	private int   mTDate;
	private int mVal;
	
	
	public MetricsSummary(String mSys, String mName, int mFDate, int mTDate, int mVal) {
		this.mSys = mSys;
		this.mName = mName;
		this.mFDate = mFDate;
		this.mTDate = mTDate;
		this.mVal = mVal;
	}
	public MetricsSummary() {
	}
	public int getmVal() {
		return mVal;
	}
	public void setmVal(int mVal) {
		this.mVal = mVal;
	}
	public int getmTDate() {
		return mTDate;
	}
	public void setmTDate(int mTDate) {
		this.mTDate = mTDate;
	}
	public int getmFDate() {
		return mFDate;
	}
	public void setmFDate(int mFDate) {
		this.mFDate = mFDate;
	}
	public String getmName() {
		return mName;
	}
	public void setmName(String mName) {
		this.mName = mName;
	}
	public String getmSys() {
		return mSys;
	}
	public void setmSys(String mSys) {
		this.mSys = mSys;
	}

}
