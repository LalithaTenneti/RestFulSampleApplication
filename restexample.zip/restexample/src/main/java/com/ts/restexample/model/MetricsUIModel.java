package com.ts.restexample.model;

public class MetricsUIModel {
	

}
