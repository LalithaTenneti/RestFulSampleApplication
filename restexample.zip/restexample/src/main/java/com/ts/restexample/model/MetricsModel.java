package com.ts.restexample.model;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class MetricsModel {
	
	private long mId;
	private String mSys;
	private String mName;
	private int   mDate;
	private int mVal;
	//private List<MetricsSummary>  mSysList;
	
	public MetricsModel() {
		
	}
	
	public MetricsModel(long mId, String mSys, String mName, int mDate, int mVal/* ,List<MetricsSummary> mSysList */ ) {
		this.mId = mId;
		this.mName = mName;
		this.mSys = mSys;
		this.mDate = mDate;
		this.mVal = mVal;
		//this.mSysList=mSysList;
	}
	public int getmVal() {
		return mVal;
	}
	public void setmVal(int mVal) {
		this.mVal = mVal;
	}
	public int getmDate() {
		return mDate;
	}
	public void setmDate(int mDate) {
		this.mDate = mDate;
	}
	public String getmSys() {
		return mSys;
	}
	public void setmSys(String mSys) {
		this.mSys = mSys;
	}
	public String getmName() {
		return mName;
	}
	public void setmName(String mName) {
		this.mName = mName;
	}
	public long getmId() {
		return mId;
	}
	public void setmId(long mId) {
		this.mId = mId;
	}

	/*
	 * public List<MetricsSummary> getmSysList() { return mSysList; }
	 * 
	 * public void setmSysList(List<MetricsSummary> mSysList) { this.mSysList =
	 * mSysList; }
	 */
	
	
	

}
