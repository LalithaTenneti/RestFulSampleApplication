package com.ts.restexample;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.ts.restexample.model.MetricsModel;
import com.ts.restexample.service.MetricsService;

/**
 * Root resource (exposed at "metrics" path)
 */
@Path("metrics")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class MyResource {

    /**
     * Method handling HTTP GET requests. The returned object will be sent
     * to the client as "text/plain" media type.
     *
     * @return String that will be returned as a text/plain response.
     */
	MetricsService service = new MetricsService();
    @GET
    public List<MetricsModel> getIt() {
        return service.getAllMetrics();
    }
    
    @GET
    @Path("/{mid}")
    public MetricsModel getMetricsId(@PathParam("mid") long mid) {
        return service.getMetricById(mid);
    }
    
    @POST
    public MetricsModel createMetric(MetricsModel metricsModel) {
        return service.createMetric(metricsModel);
    }
    
    @PUT
    @Path("/{mid}")
    public MetricsModel updateMetric(@PathParam("mid") long mid,MetricsModel metricsModel) {
    	metricsModel.setmId(mid);
    	return service.updateMetric(metricsModel);
    }
}
