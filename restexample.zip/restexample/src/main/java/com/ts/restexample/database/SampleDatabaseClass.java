package com.ts.restexample.database;

import java.util.HashMap;
import java.util.Map;

import com.ts.restexample.model.MetricsModel;

public class SampleDatabaseClass {
	
	private static Map<Long, MetricsModel>  measurements = new HashMap<Long, MetricsModel>();

	public static Map<Long, MetricsModel> getMeasurements() {
		return measurements;
	}

}
