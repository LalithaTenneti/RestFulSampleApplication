package com.ts.restexample.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import com.ts.restexample.database.SampleDatabaseClass;
import com.ts.restexample.model.MetricsModel;


public class MetricsService {
	
	private Map<Long, MetricsModel>  measurements =SampleDatabaseClass.getMeasurements();
	
	
public MetricsService() {
	measurements.put(1L, new MetricsModel(1l, "Weather", "Temperature", 10, 101));
	measurements.put(2L, new MetricsModel(2l, "Weather", "Temperature", 20, 201));
}
	
	 
	public List<MetricsModel> getAllMetrics(){
		
		/*
		 * List<MetricsModel> list = new ArrayList<MetricsModel>();
		 * 
		 * List<MetricsSummary> mSumaryList = new ArrayList<MetricsSummary>();
		 * MetricsSummary summary1 = new MetricsSummary("Weather", "Temperature", 50,
		 * 60, 101); MetricsSummary summary2 = new MetricsSummary("Weather",
		 * "Temperature", 30, 50, 103); mSumaryList.add(summary1);
		 * mSumaryList.add(summary2);
		 * 
		 * MetricsModel model1 = new MetricsModel(1l, "Weather", "Temperature", 10,
		 * 101,mSumaryList);
		 * 
		 * MetricsModel model2 = new MetricsModel(2l, "Weather", "Temperature", 20,
		 * 103,mSumaryList); list.add(model1); list.add(model2);
		 */
		return new ArrayList<MetricsModel> (measurements.values());
	}
	
	public MetricsModel  getMetricById(long mId) {
		
		return measurements.get(mId);
		
	}
	
public MetricsModel  createMetric(MetricsModel metricsModel) {
	if(metricsModel == null) {
		metricsModel = new MetricsModel();
	}
	//MetricsModel metricsModel = new MetricsModel();
	metricsModel.setmId(measurements.size()+1);
	//metricsModel.setmSys(mSys);
	//metricsModel.setmName(mName);
	metricsModel.setmVal(metricsModel.getmVal()>=0?metricsModel.getmVal():1);
	Long date =new Date().getTime();
	metricsModel.setmDate(metricsModel.getmDate()>=0?metricsModel.getmDate():date.intValue());
	measurements.put(metricsModel.getmId(), metricsModel);
	return metricsModel;
}
		
	

public MetricsModel  updateMetric(MetricsModel metricsModel) {
	if(metricsModel.getmId()<=0) {
		return null;
	}else {
		MetricsModel oldModel =measurements.get(metricsModel.getmId());
		metricsModel.setmVal(metricsModel.getmVal()<0?oldModel.getmVal()+1:metricsModel.getmVal());
		measurements.put(metricsModel.getmId(), metricsModel);
		return metricsModel;
	}
	
}

}
